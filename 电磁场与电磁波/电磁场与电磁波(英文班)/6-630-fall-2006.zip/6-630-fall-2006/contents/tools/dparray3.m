function dparray3(N,d,alpha)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%R = zeros(size(phi2));
phi = (-2*pi):pi/150:(pi/2);
theta = 0:pi/150:pi;
k = 2*pi;

[phi2,theta2] = meshgrid(phi,theta);

R = zeros(size(phi2));

%R = abs(R);
R = abs(sin(theta2));
R = R./(max(max(R)));

[XX,YY,ZZ] = sph2cart(phi2,pi/2-theta2,R);

CC = R;
%./max(max(R));
%CC = ones(size(R));
%subplot(2,1,2),surf(XX,YY,ZZ,CC);
figure(1)
subplot(1,2,1),surf(XX,YY,ZZ);
colormap(winter);shading interp;
%light;lighting phong;material shiny;
%colorbar
axis equal
axis off
%xlabel('x axis'); ylabel('y axis'); zlabel('z axis')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

phi = (-2*pi):pi/150:(pi/2);
theta = 0:pi/150:pi;
k = 2*pi;

[phi2,theta2] = meshgrid(phi,theta);

R = zeros(size(phi2));
for n = 0:(N-1),
  u = k*d*cos(phi2).*sin(theta2) + alpha;
  R = R + exp(j*n*u);
end
R = abs(R);
%R = abs(sin(theta2).*R);
%R = R./(max(max(R)));

[XX,YY,ZZ] = sph2cart(phi2,pi/2-theta2,R);

CC = R;
%./max(max(R));
%CC = ones(size(R));
subplot(1,2,2),surf(XX,YY,ZZ);
colormap(winter);shading interp;
%light;lighting phong;material shiny;
%colorbar
axis equal
axis off
%xlabel('x axis'); ylabel('y axis'); zlabel('z axis')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(2)
phi = (-2*pi):pi/150:(pi/2);
theta = 0:pi/150:pi;
k = 2*pi;

[phi2,theta2] = meshgrid(phi,theta);

R = zeros(size(phi2));
for n = 0:(N-1),
  u = k*d*cos(phi2).*sin(theta2) + alpha;
  R = R + exp(j*n*u);
end
R = abs(R);
R = abs(sin(theta2).*R);
%R = R./(max(max(R)));

[XX,YY,ZZ] = sph2cart(phi2,pi/2-theta2,R);

CC = R;
%./max(max(R));
%CC = ones(size(R));
surf(XX,YY,ZZ);
colormap(winter);shading interp;
%light;lighting phong;material shiny;
colorbar
axis equal
xlabel('x axis'); ylabel('y axis'); zlabel('z axis')


