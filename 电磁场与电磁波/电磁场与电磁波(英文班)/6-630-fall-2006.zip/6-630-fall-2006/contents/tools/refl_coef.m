function refl_coef(kappa1,kappa2,thetai)

% REFL_COEF(KAPPA1,KAPPA2,THETAI) plots the TE and TM reflection
% coefficients for a dielectric material interface between region "1" 
% with dielectric constant KAPPA1 and region "2" with dielectric 
% constant KAPPA2 for incident angles in the vector THETAI (degrees).
%
% NOTE: EPSILON = KAPPA * EPSILON_o 
%

% J. Pacheco
% 6.014 Problem 6.2 Soln

% convert theta to radians
thetai = thetai*pi/180;

p12 = sqrt((kappa2/kappa1) - (sin(thetai)).^2)./cos(thetai);
rte = (1-p12)./(1+p12);

p12 = p12.*(kappa1/kappa2);
rtm = (1-p12)./(1+p12);

% convert back to degrees
thetai = thetai*180/pi;

subplot(211)
plot(thetai,abs(rte.*conj(rte)),thetai,abs(rtm.*conj(rtm)),'--');
xlabel('\theta_i'); grid on;
legend('| R^{TE} |^2','| R^{TM} |^2' ,0);
title(['kappa_1 = ' num2str(kappa1) ', kappa_2 = ' num2str(kappa2)]);

subplot(212)
plot(thetai,angle(rte)/pi,thetai,angle(rtm)/pi,'--');
xlabel('\theta_i'); ylabel('\phi / \pi');
axis([min(thetai) max(thetai) -2.1 2.1])
legend('R^{TE} phase','R^{TM} phase',0);
grid on;


